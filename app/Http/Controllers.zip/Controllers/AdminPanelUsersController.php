<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Models\Adminpanel;
class AdminPanelUsersController extends Controller
{
    public function index(Adminpanel $adminpanel){
        //dd($adminpanel->getNewUsers());
        return view('adminpanel.new_users',['users' => $adminpanel->getNewUsers()]);
    }

    public function sendActivateCode(Adminpanel $adminpanel, $id){
        //user = $adminpanel->getNewUserInfo($id);
        $adminpanel->sendActivateCode($id);
        return redirect('/adminpanel/users');
    }

    public function viewUserInner(Adminpanel $adminpanel, $id){
        //dd($adminpanel->getNewUserInfo($id));
        return view('adminpanel.users-inner', ['user' => $adminpanel->getNewUserInfo($id)]);
    }

    public function allUsers(){
        return view('adminpanel.all-users', ['users' => User::orderBy('created_at', 'desc')->get()]);
    }

    public function allUsersProfile(Adminpanel $adminpanel, $id){
        return view('adminpanel.all-users-profile', ['user' => $adminpanel->getNewUserInfo($id)]);
    }

}
