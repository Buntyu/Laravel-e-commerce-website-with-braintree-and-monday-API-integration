<?php

namespace App\Http\Controllers;

use App\Models\Faq;
use App\Models\Shipping;
use App\Models\Terms;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Models\Testimonials;
use App\Models\AdditionalService;
use App\Models\Size;
use App\Models\OurClient;
use App\Models\Border;
class AdminPanelPagesController extends Controller
{
    public function index(){

        return view('adminpanel.pages');
    }

    public function getTestimonials(Testimonials $testimonials){

        return view('adminpanel.testimonials' ,['testimonials' => $testimonials->getTestimonials()]);
    }

    public function addTestimonials(Testimonials $testimonials, Request $request){
        $testimonials->addTesimonials($request->all());
        return redirect('adminpanel/pages/testimonials');
    }

    public function deleteTestimonials(Testimonials $testimonials, Request $request){
        $testimonials->deleteTestimonials($request->all());
        return redirect('adminpanel/pages/testimonials');
    }

    public function getAdditionalServices(AdditionalService $additionalService){

        return view('adminpanel.additional-services', ['additional_services' => $additionalService->getAdditionalServices()]);
    }

    public function addAdditionalServices(AdditionalService $additionalService, Request $request){
        //$testimonials->addTesimonials($request->all());
        $additionalService->addAdditionalServices($request->all(), $request->file());
        return redirect('adminpanel/pages/additional-services');
    }

    public function editAdditionalServices(AdditionalService $additionalService, Request $request){
        $additionalService->editAdditionalServices($request->all(), $request->file());
        return redirect('adminpanel/pages/additional-services');
    }

    public function indexEditSizes(Size $size){
        $photo = $size->getSize('photo');
        $square = $size->getSize('square');
        $panoramic = $size->getSize('panoramic');

        return view('adminpanel.sizes', ['photo' => $photo, 'square' => $square, 'panoramic' => $panoramic]);
    }

    public function editSizes(Request $request, Size $size){
        $size->editSize($request->all());
        return redirect('adminpanel/pages/sizes');
    }

    public function editOurClients(OurClient $client){
        return view('adminpanel.our-clients', ['our_clients'=>$client->getClients()]);
    }

    public function addOurClients(OurClient $client, Request $request){
        $client->addClients($request->file());
        return redirect('adminpanel/pages/our-clients');
    }

    public function deleteOurClients(Request $request, OurClient $ourClient){
        $ourClient->deleteClients($request->all());
        return redirect('adminpanel/pages/our-clients');
    }

    public function editBorderPrice(Border $border){
        return view('adminpanel.border-price',['raw' => $border->getBorderPrice(1), 'white' => $border->getBorderPrice(2), 'black' => $border->getBorderPrice(3)]);
    }

    public function editCoupon(){

    }

    public function editFaq(){
        return view('adminpanel.faq', ['faq' => Faq::first()]);
    }

    public function postEditFaq(Request $request, Faq $faq){
        $faq->editContent($request);
        return redirect()->back();
    }

    public function editTerms(){
        return view('adminpanel.terms', ['terms' => Terms::first()]);
    }

    public function postEditTerms(Request $request, Terms $terms){
        $terms->editContent($request);
        return redirect()->back();
    }

    public function editShipping(){
        return view('adminpanel.shipping', ['shipping' => Shipping::first()]);
    }

    public function postEditShipping(Request $request, Shipping $shipping){
        $shipping->editContent($request);
        return redirect()->back();
    }


}
