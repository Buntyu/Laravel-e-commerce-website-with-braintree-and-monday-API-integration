<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Models\Testimonials;
use App\Models\AdditionalService;
use App\Models\OurClient;
class LpCommercialPrintingController extends Controller
{
    public function index(Testimonials $testimonials, AdditionalService $additionalService, OurClient $ourClient){
        return view('canvas.landing-pages.commercial_printing' ,['testimonials' => $testimonials->getTestimonials(), 'additionalService' => $additionalService->getAdditionalServices(),'our_clients' => $ourClient->getClients()]);
    }


}
