<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Models\Adminpanel;

class AdminPanelController extends Controller
{
    public function index(Adminpanel $adminpanel){
        $ordersCount = $adminpanel->getOrdersCount();
        $userCount= $adminpanel->getUserCount() - 1;
        $imagesCount= $adminpanel->getImagesCount();

        $latestUser = $adminpanel->getLatestUser();

        //dd($ordersCount);
        return view('adminpanel.index', ['ordersCount' => $ordersCount, 'userCount' => $userCount, 'imagesCount'=>$imagesCount, 'latestUser' => $latestUser]);
    }



}
